import sqlite3

def get_planets():
    con = sqlite3.connect('static/planets.db')
    query = con.execute("SELECT name from planets")
    data = query.fetchall()
    data = [item[0] for item in data]
    return data

def get_planets_info_by_name(name):
    con = sqlite3.connect('static/planets.db')
    query = con.execute(f"SELECT * FROM planets WHERE name = '{name}'")
    data = query.fetchone()
    return data